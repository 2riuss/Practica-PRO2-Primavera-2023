var searchData=
[
  ['eliminar_5fprioridad_10',['eliminar_prioridad',['../classArea__Espera.html#a229437d0468e736997cb6a09f90d4736',1,'Area_Espera']]],
  ['eliminar_5fproceso_11',['eliminar_proceso',['../classCjt__procesos.html#a9f2ebcc293b601973d92dbee7e58a961',1,'Cjt_procesos::eliminar_proceso()'],['../classCluster.html#af5cb352414a4b311874c3cb6d814e27f',1,'Cluster::eliminar_proceso()'],['../classProcesador.html#a14d241dba3664f20d9ba3000951b3831',1,'Procesador::eliminar_proceso()']]],
  ['enviar_5fprocesos_5fcluster_12',['enviar_procesos_cluster',['../classArea__Espera.html#a9beaaa1454da8434e875014de897d8af',1,'Area_Espera']]],
  ['escribir_5farea_5fespera_13',['escribir_area_espera',['../classArea__Espera.html#aa218e55b81276e4e1f7474d951018557',1,'Area_Espera']]],
  ['escribir_5fcjt_5fprocesos_14',['escribir_Cjt_procesos',['../classCjt__procesos.html#a51519f7dfb655da366b2140e379f0344',1,'Cjt_procesos']]],
  ['escribir_5festructura_15',['escribir_estructura',['../classCluster.html#a8a02b0ac39096492d3294dcb4c146473',1,'Cluster']]],
  ['escribir_5fprioridad_16',['escribir_prioridad',['../classArea__Espera.html#ac15e2e57cf4713f8ff931ab51552647d',1,'Area_Espera']]],
  ['escribir_5fprocesador_17',['escribir_procesador',['../classCluster.html#a5d9669f4499e5a61b5b1ef74bc94b822',1,'Cluster::escribir_procesador()'],['../classProcesador.html#a4caee6887c95a30d244fa996b0cdd788',1,'Procesador::escribir_procesador()']]],
  ['escribir_5fprocesadores_18',['escribir_procesadores',['../classCluster.html#a85ca8561b46b8324e71261fd99c0eb52',1,'Cluster']]],
  ['escribir_5fproceso_19',['escribir_proceso',['../classProceso.html#a5e2a9c28d74a9398ee095d5f04d59836',1,'Proceso']]],
  ['existe_5fprioridad_20',['existe_prioridad',['../classArea__Espera.html#a88234c39549de7308c20c3b3fab1256d',1,'Area_Espera']]],
  ['existe_5fprocesador_21',['existe_procesador',['../classCluster.html#a00c7c6cee7ff9b2d4eac94f08162e55c',1,'Cluster']]],
  ['existe_5fproceso_22',['existe_proceso',['../classCjt__procesos.html#a32efff235187c9870fb5103d89ffcced',1,'Cjt_procesos::existe_proceso()'],['../classCluster.html#a0376272198129660dc99a07d4c068a75',1,'Cluster::existe_proceso()'],['../classProcesador.html#ab2bb5ad6a65b5647593f189561836b18',1,'Procesador::existe_proceso()']]]
];
