var searchData=
[
  ['procesador_78',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a8fcdb116e68accc213610b95b50a07a5',1,'Procesador::Procesador(int mem)']]],
  ['procesador_5fvacio_79',['procesador_vacio',['../classCluster.html#a041ddf923742a357c9b4a3600e35f4d3',1,'Cluster']]],
  ['proceso_80',['proceso',['../classCjt__procesos.html#a36634c7fd425cba02251a36b184f0a1d',1,'Cjt_procesos']]],
  ['proceso_81',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];
