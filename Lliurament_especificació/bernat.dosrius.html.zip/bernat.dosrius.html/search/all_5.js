var searchData=
[
  ['main_27',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mem_28',['mem',['../classProceso.html#a915a70e88bbe621cfb57d48d95ecd73d',1,'Proceso']]]
];
