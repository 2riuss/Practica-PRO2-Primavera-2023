var searchData=
[
  ['pràctica_20bernat_20dosrius_20lleonart_3a_20simulando_20una_20arquitectura_20multiprocesador_85',['Pràctica Bernat Dosrius Lleonart: Simulando una arquitectura multiprocesador',['../index.html',1,'']]]
];
