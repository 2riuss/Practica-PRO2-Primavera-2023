var searchData=
[
  ['agregar_5fprioridad_52',['agregar_prioridad',['../classArea__Espera.html#a93dad5b04ffc5565e98e3d468790dff9',1,'Area_Espera']]],
  ['agregar_5fproceso_53',['agregar_proceso',['../classArea__Espera.html#a0b107f3ece9ff2e6bcf7429705a8d0c0',1,'Area_Espera::agregar_proceso()'],['../classCjt__procesos.html#a4acbe5015edb0a970ba50feb8eabcd0d',1,'Cjt_procesos::agregar_proceso()'],['../classCluster.html#ad11534115209ea88728130754ab99150',1,'Cluster::agregar_proceso(const string &amp;id, const Proceso &amp;job)'],['../classCluster.html#a32e3da70b390adf92bba5370a2db48b8',1,'Cluster::agregar_proceso(const Proceso &amp;job)'],['../classProcesador.html#a73c96eaae40b5480c7a4051e27d2f8df',1,'Procesador::agregar_proceso()']]],
  ['area_5fespera_54',['Area_Espera',['../classArea__Espera.html#a260d02d0043e1fd9d8ce6e08de930c63',1,'Area_Espera']]],
  ['avanzar_5ftiempo_55',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#aacfa317b627623ffde171bd0e1419ac8',1,'Proceso::avanzar_tiempo()']]]
];
