var searchData=
[
  ['vacio_84',['vacio',['../classCjt__procesos.html#aa2745f3932bee4b8ef66fed7b3fce691',1,'Cjt_procesos::vacio()'],['../classProcesador.html#aa0cc3905c36dac0d66b2c078d4950eab',1,'Procesador::vacio()']]]
];
