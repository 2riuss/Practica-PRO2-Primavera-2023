var searchData=
[
  ['cjt_5fprocesos_56',['Cjt_procesos',['../classCjt__procesos.html#aad797081bc97ff69600c47a98e56b8a2',1,'Cjt_procesos']]],
  ['cluster_57',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_5fmemoria_58',['compactar_memoria',['../classCluster.html#a8f16bf02da721bf1053f7bc8b11a9df5',1,'Cluster::compactar_memoria(const string &amp;id)'],['../classCluster.html#a622839c3b8dc923dc36f6026f35db269',1,'Cluster::compactar_memoria()'],['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador::compactar_memoria()']]]
];
