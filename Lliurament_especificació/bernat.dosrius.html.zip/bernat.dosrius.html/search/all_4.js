var searchData=
[
  ['leer_5fcluster_24',['leer_cluster',['../classCluster.html#a1823bab6dff05332c50e507d5e5c6107',1,'Cluster']]],
  ['leer_5fprioridades_25',['leer_prioridades',['../classArea__Espera.html#ac308b8a8b5991c87c2475f29e2bbbe4f',1,'Area_Espera']]],
  ['leer_5fproceso_26',['leer_proceso',['../classProceso.html#acfc1b59d4fa0dd7bba4d02c6c6880ea9',1,'Proceso']]]
];
