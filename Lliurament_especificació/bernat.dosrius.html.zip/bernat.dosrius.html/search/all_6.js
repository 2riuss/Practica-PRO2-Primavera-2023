var searchData=
[
  ['procesador_29',['Procesador',['../classProcesador.html',1,'Procesador'],['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a8fcdb116e68accc213610b95b50a07a5',1,'Procesador::Procesador(int mem)']]],
  ['procesador_2ehh_30',['Procesador.hh',['../Procesador_8hh.html',1,'']]],
  ['procesador_5fvacio_31',['procesador_vacio',['../classCluster.html#a041ddf923742a357c9b4a3600e35f4d3',1,'Cluster']]],
  ['proceso_32',['Proceso',['../classProceso.html',1,'']]],
  ['proceso_33',['proceso',['../classCjt__procesos.html#a36634c7fd425cba02251a36b184f0a1d',1,'Cjt_procesos']]],
  ['proceso_34',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]],
  ['proceso_2ehh_35',['Proceso.hh',['../Proceso_8hh.html',1,'']]],
  ['program_2ecc_36',['program.cc',['../program_8cc.html',1,'']]],
  ['pràctica_20bernat_20dosrius_20lleonart_3a_20simulando_20una_20arquitectura_20multiprocesador_37',['Pràctica Bernat Dosrius Lleonart: Simulando una arquitectura multiprocesador',['../index.html',1,'']]]
];
