var searchData=
[
  ['procesador_33',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_34',['Proceso',['../classProceso.html',1,'']]]
];
